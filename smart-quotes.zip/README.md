Source code of [Blogger Smart Punctuations](https://chrome.google.com/webstore/detail/kemhapeegihkkkjbhnepbpkklbmpbgfn) Chrome extension.
